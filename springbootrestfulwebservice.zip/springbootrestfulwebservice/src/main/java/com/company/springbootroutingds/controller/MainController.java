package com.company.springbootroutingds.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.company.springbootroutingds.advertiser.model.Advertiser;
import com.company.springbootroutingds.dao.AdvertiserDAO;
import com.company.springbootroutingds.dao.PublisherDAO;
import com.company.springbootroutingds.model.Publisher;

@Controller
public class MainController {

/*    @Autowired
    private DataDAO dataDAO;*/
    
    @Autowired
    private PublisherDAO publisherDAO;
 
    @Autowired
    private AdvertiserDAO advertiserDAO;

    @RequestMapping(value = {"/"}, method = RequestMethod.GET)
    public String home(Model model) throws SQLException{
    	 List<Advertiser> advertisers = advertiserDAO.listAdvertisers();
         List<Publisher> publishers = publisherDAO.listPublishers();
  
         model.addAttribute("advertisers", advertisers);
         model.addAttribute("publishers", publishers);
         
        return "home";
    }

    @RequestMapping(value = {"/publisher/list"}, method = RequestMethod.GET)
    public String publisher(Model model) throws SQLException{
        List<Publisher> list = publisherDAO.listPublishers();
        model.addAttribute("publishers", list);

        return "publisher";
    }

    @RequestMapping(value = {"/advertiser/list"}, method = RequestMethod.GET)
    public String advertiser(Model model) throws SQLException{
        List<Advertiser> list = advertiserDAO.listAdvertisers();
        model.addAttribute("advertisers", list);

        return "advertiser";
    }
}
