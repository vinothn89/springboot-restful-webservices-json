package com.company.springbootroutingds.config;

public class Constants {
    
    public static final String PACKAGE_ENTITIES_1 = "com.company.springbootroutingds.model";
     
    public static final String PACKAGE_ENTITIES_2 = "com.company.springbootroutingds.advertiser.model";
     
    public static final String JPA_UNIT_NAME_1 ="PERSITENCE_UNIT_NAME_1";
    public static final String JPA_UNIT_NAME_2 ="PERSITENCE_UNIT_NAME_2";
     
}