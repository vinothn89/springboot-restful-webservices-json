package com.company.springbootroutingds.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.company.springbootroutingds.dao.PublisherDAO;
import com.company.springbootroutingds.model.Publisher;

@Controller
public class PublisherController {
  
  @Autowired
  private PublisherDAO publisherDAO;
  
  @RequestMapping(method = RequestMethod.GET, value="/publisher/pdetails")
  
  @ResponseBody
  public List<Publisher> getPdetails() {
	  List<Publisher> publishers = publisherDAO.listPublishers();
	  return publishers;
  }
}
